# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyscreencap']

package_data = \
{'': ['*']}

install_requires = \
['PyAutoGUI>=0.9.52,<0.10.0',
 'numpy>=1.19.2,<2.0.0',
 'opencv-python>=4.4.0,<5.0.0']

setup_kwargs = {
    'name': 'pyscreencap',
    'version': '0.6.0',
    'description': 'A python based screen recorder - and for free!',
    'long_description': '# screen-recorder\nA free screen recorder written with python. Sick of paywalled screen recording, overcomplicated setups etc.\n\n## Install Dependencies\n\nRun the below command to install Python dependencies:\n\n```bash\npip install -r requirements.txt\n```\n\n## Running the Recorder\n\nTo run the recorder, run the following command:\n\n```bash\npython record.py\n```\n\nRecorded files will be created under `recordings\\`.',
    'author': 'Tom Thornton',
    'author_email': 'thomas.thornton92@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
