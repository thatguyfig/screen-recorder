# screen-recorder
A free screen recorder written with python. Sick of paywalled screen recording, overcomplicated setups etc.

## Install Dependencies

Run the below command to install Python dependencies:

```bash
pip install -r requirements.txt
```

## Running the Recorder

To run the recorder, run the following command:

```bash
python record.py
```

Recorded files will be created under `recordings\`.