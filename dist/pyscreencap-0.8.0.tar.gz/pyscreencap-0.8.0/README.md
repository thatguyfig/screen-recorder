# PyScreenCap
A free screen recorder written with python. Sick of paywalled screen recording, overcomplicated setups etc.

## Running the Recorder

To run the recorder, run the following command:

```bash
python -m pyscreencap
```

Recorded files will be created the directory `pyscreencap-recordings` in your user profile.