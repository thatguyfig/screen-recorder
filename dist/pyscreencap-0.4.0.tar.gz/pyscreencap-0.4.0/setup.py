# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyscreencap']

package_data = \
{'': ['*']}

install_requires = \
['PyAutoGUI>=0.9.52,<0.10.0',
 'numpy>=1.19.2,<2.0.0',
 'opencv-python>=4.4.0,<5.0.0']

setup_kwargs = {
    'name': 'pyscreencap',
    'version': '0.4.0',
    'description': 'A python based screen recorder - and for free!',
    'long_description': None,
    'author': 'Tom Thornton',
    'author_email': 'thomas.thornton92@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
